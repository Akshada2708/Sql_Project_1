-- Create Database

create database Assignment1

-- use database

use Assignment1

-- create table Salesman

CREATE TABLE Salesman (
SalesmanId INT, Name VARCHAR(255),Commission DECIMAL(10, 2),City VARCHAR(255), Age INT
);

INSERT INTO Salesman (SalesmanId, Name, Commission, City, Age)
VALUES
    (101, 'Joe', 50, 'California', 17),
    (102, 'Simon', 75, 'Texas', 25),
    (103, 'Jessie', 105, 'Florida', 35),
    (104, 'Danny', 100, 'Texas', 22),
    (105, 'Lia', 65, 'New Jersey', 30)

select * from Salesman

-- create table Customer

CREATE TABLE Customer (
    SalesmanId INT,
    CustomerId INT,
    CustomerName VARCHAR(255),
    PurchaseAmount INT,
    );

INSERT INTO Customer (SalesmanId, CustomerId, CustomerName, PurchaseAmount)
VALUES
    (101, 2345, 'Andrew', 550),
    (103, 1575, 'Lucky', 4500),
    (104, 2345, 'Andrew', 4000),
    (107, 3747, 'Remona', 2700),
    (110, 4004, 'Julia', 4545)

select * from Customer

-- create table Orders


CREATE TABLE Orders (OrderId int, CustomerId int, SalesmanId int, Orderdate Date, Amount money)

INSERT INTO Orders Values 
(5001,2345,101,'2021-07-01',550),
(5003,1234,105,'2022-02-15',1500)

select * from Orders

-- Task 1
-- 1) Insert a new record in your Orders table.

insert into orders values (5004, 3245, 106,'2023-03-27', 2000)

select * from Orders

-- Task 2
-- Add Primary key constraint for SalesmanId column in Salesman table. Add default
-- constraint for City column in Salesman table. Add Foreign key constraint for SalesmanId
-- column in Customer table. Add not null constraint in Customer_name column for the Customer table.--Adding Primary Key Constraint to SalesmanId in Salesman Table

alter table salesman alter column salesmanid int not null

alter table Salesman
add constraint  pri_key_salesman PRIMARY KEY (SalesmanId);select * from Salesman-- Adding Default Constraint to City in Salesman Table

select * from Salesman

alter table Salesman add constraint Def_Salesman_City default 'Not Known' FOR City-- Setting default value as "Not Known" if the city is not mentioned.insert into Salesman (SalesmanId, name, Commission, age)values (106, 'Akshada', 60, 23)select * from Salesmanselect * from Customer-- Adding Foreign Key Constraint to SalesmanId in Customer Table

insert into salesman values(107, 'Ashwin', 75, 'New York', 18),
(110, 'Jenny', 90, 'Boston', 30)

alter table Customer add constraint for_key_Cust_Salesman foreign key (SalesmanId)
references Salesman (SalesmanId)

-- Updating CustomerName as 'Not Known' if not mentioned and setting it to not Null value

update customer set CustomerName = 'Not known' where customername is Nullalter table customer alter column customername varchar(255)  not null-- Task 3-- Fetch the data where the Customer�s name is ending with �N� also get the purchase
-- amount value greater than 500.select * from Customerwhere customername like '%N' and PurchaseAmount > 500 -- Since there is no name ending with 'N' the query will run but will not display any value.-- Task 4--Using SET operators, retrieve the first result with unique SalesmanId values from two
-- tables, and the other result containing SalesmanId with duplicates from two tables.select * from Salesmanselect * from customer-- Unique valuesselect SalesmanId from salesman Union select salesmanid from customer -- Duplicate valuesselect SalesmanId
from (select SalesmanId from Customer
    UNION ALL 
	select SalesmanId
    from Salesman
) AS TotalSalesman
group by SalesmanId
having count(SalesmanId) > 1;

-- Task 5
-- Display the below columns which has the matching data.
-- Orderdate, Salesman Name, Customer Name, Commission, and City which has the
-- range of Purchase Amount between 500 to 1500.

select * from Salesmanselect * from customer
select * from Orders

select  O.Orderdate, S.Name AS SalesmanName, C.CustomerName, S.Commission, S.City
from Orders O
join 
Customer C ON O.CustomerId = C.CustomerId
join
Salesman S ON O.SalesmanId = S.SalesmanId
where 
C.PurchaseAmount BETWEEN 500 AND 1500;

-- There is only one customer Andrew valid for above query

-- Task 6
-- Using right join fetch all the results from salesman and orders table

select * from Salesman
select * from Orders

select * from salesman S right join orders O on S.SalesmanId = o.SalesmanId

---------------------------------------------------xxx--------------------------------------------------------------------------





